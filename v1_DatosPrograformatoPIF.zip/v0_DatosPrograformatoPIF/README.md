# 📄 Proyecto Integrador de Saberes - LaTeX

## 🎯 Descripción

Documento de investigación formativa que integra **Programación I** (Mg. José Zúñiga) y **Estructura de Datos** (Mg. Evelyn Rosero), analizando el rendimiento de algoritmos de ordenamiento (Merge Sort vs Radix Sort) aplicados a placas vehiculares ecuatorianas.

---

## 📦 Archivos del Proyecto

```
v0_DatosPrograformatoPIF/
├── main_completo.tex          ← Documento principal (39 KB)
├── referencias.bib            ← 10 referencias académicas (2.2 KB)
├── diagramas_uml.tex          ← 8 diagramas UML opcionales (23 KB)
├── insertar_diagramas.tex     ← Guía de integración de diagramas
├── logo_unach.png             ← Logo institucional
├── logo_white_unach.png       ← Logo portada
├── logo_sgc.png               ← Logo SGC
└── README.md                  ← Este archivo
```

---

## ⚡ Compilación Rápida

### Opción 1: Con latexmk (Recomendado)

```bash
latexmk -pdf -bibtex main_completo.tex
```

### Opción 2: Manual

```bash
pdflatex main_completo.tex
bibtex main_completo
pdflatex main_completo.tex
pdflatex main_completo.tex
```

**Resultado**: `main_completo.pdf` (~20-25 páginas)

---

## 📊 Contenido del Documento

### Estructura (10 secciones principales)

1. **Autores** - 6 estudiantes
2. **Personal Académico** - Mg. José Zúñiga + Mg. Evelyn Rosero
3. **Integración de Sílabos** - Vinculación Programación I + Estructura de Datos
4. **Resultados de Aprendizaje**
5. **Tema de la Actividad**
6. **Objetivos** - General + 5 específicos
7. **Desarrollo del Informe** (núcleo del documento):
   - 7.1 Introducción
   - 7.2 Marco Teórico
   - 7.3 Metodología y Arquitectura
   - 7.4 Implementación Técnica (Merge Sort + Radix Sort + Binary Search)
   - 7.5 Integración con Pandas y Visualización
   - 7.6 Resultados Experimentales
   - **7.7 Análisis de la Hipótesis** ⭐ (Rechazo fundamentado)
   - 7.8 Casos de Uso
   - 7.9 Generación de Datos
8. **Conclusiones** - Técnicas, académicas, recomendaciones
9. **Impacto y Relevancia**
10. **Referencias** - 10 fuentes académicas

---

## 🎯 Sección Clave: Análisis de la Hipótesis

### Hipótesis Original
"Radix Sort superará a Merge Sort en el ordenamiento de placas vehiculares"

### Resultado Experimental
- **Merge Sort**: 1.7234 ms (promedio)
- **Radix Sort**: 1.7189 ms (promedio)
- **Diferencia**: 0.0045 ms (0.26%) - Rendimiento equivalente

### Conclusión
✅ **SE RECHAZA LA HIPÓTESIS**

### Justificación Científica
1. **Tamaño de muestra insuficiente** (n=1000) para ventaja asintótica
2. **Overhead de múltiples pasadas** en Radix Sort (7 iteraciones)
3. **Constantes ocultas en Big-O** afectan rendimiento real
4. **Localidad de caché** favorece a Merge Sort

**Lección académica**: La complejidad asintótica no es suficiente para predecir rendimiento real. Los factores prácticos son decisivos.

---

## 🎨 Diagramas UML (Opcional)

El archivo `diagramas_uml.tex` contiene 8 diagramas profesionales:

1. **Complejidad Algorítmica** - Gráfico O(n log n) vs O(d·n)
2. **Arquitectura del Sistema** - Capas MVC
3. **Flujo de Búsqueda** - Proceso completo
4. **Diagrama de Secuencia** - Interacción temporal
5. **Casos de Uso** - Actores y sistema
6. **Merge Sort** - Flowchart del algoritmo
7. **Radix Sort** - Flowchart del algoritmo
8. **Modelo de Datos** - Diagrama ER

### Para integrarlos:

**IMPORTANTE**: El archivo `diagramas_uml.tex` debe cargarse DESPUÉS de `\begin{document}`, NO en el preámbulo.

**Paso 1**: Verificar que el preámbulo de `main_completo.tex` tenga (ya está incluido):
```latex
\usepackage{tikz}
\usetikzlibrary{shapes.geometric, arrows, positioning, fit, backgrounds, calc, shapes.multipart}
```

**Paso 2**: Agregar después de `\begin{document}`:
```latex
\input{diagramas_uml.tex}
```

**Paso 2**: Insertar en las ubicaciones indicadas en `insertar_diagramas.tex`:
```latex
\diagramaComplejidad      % Sección 7.2
\diagramaArquitectura     % Sección 7.3.1
\diagramaFlujoBusqueda    % Sección 7.3.2
\diagramaSecuencia        % Sección 7.3.2
\diagramaCasosUso         % Después 7.3
\diagramaFlujoMergeSort   % Sección 7.4.1
\diagramaFlujoRadixSort   % Sección 7.4.2
\diagramaModeloDatos      % Sección 7.8
```

---

## ✅ Verificación del PDF

Después de compilar, verifica:

- [ ] Portada con logos UNACH
- [ ] Tabla de contenidos generada
- [ ] Ambos docentes listados (Zúñiga + Rosero)
- [ ] Sección 3: Integración de sílabos
- [ ] Códigos Python con resaltado de sintaxis
- [ ] Tabla 1: Resultados experimentales
- [ ] Sección 7.7: Rechazo de hipótesis
- [ ] 10 referencias en bibliografía
- [ ] Citas funcionando (ej: Cormen et al., 2022)
- [ ] ~20-25 páginas totales

---

## 🎓 Características Destacadas

### 1. Método Científico Completo
- Hipótesis → Experimentación → Análisis → Conclusión
- Rechazo fundamentado (honestidad académica)

### 2. Implementación Técnica Profesional
- Código Python completo (no pseudocódigo)
- Merge Sort: O(n log n) con análisis detallado
- Radix Sort: O(d·n) con análisis detallado
- Binary Search: O(log n)

### 3. Integración Curricular Auténtica
- **Programación I**: Pandas, NumPy, Flask, Matplotlib, modularización
- **Estructura de Datos**: Complejidad algorítmica, algoritmos de ordenamiento

### 4. Referencias de Calidad
- Cormen (Introduction to Algorithms, MIT Press)
- Knuth (The Art of Computer Programming)
- Papers científicos (Nature: NumPy)
- ANT Ecuador (contexto nacional)

### 5. Análisis Crítico
- Teoría vs práctica
- Constantes ocultas en Big-O
- Factores de hardware (caché)

---

## 📚 Referencias Incluidas

1. Cormen et al. (2022) - Introduction to Algorithms (4th ed.)
2. Knuth (1998) - The Art of Computer Programming Vol. 3
3. McIlroy et al. (1993) - Engineering Radix Sort
4. Sedgewick & Wayne (2011) - Algorithms
5. Weiss (2013) - Data Structures and Algorithm Analysis
6. McConnell (2004) - Code Complete
7. McKinney (2010) - Pandas
8. Harris et al. (2020) - NumPy (Nature)
9. ANT Ecuador (2024) - Sistema de consulta vehicular
10. Hunter (2007) - Matplotlib

---

## 🔧 Solución de Problemas

### Error: Archivos de logo no encontrados
Asegúrate de que los 3 archivos PNG estén en el mismo directorio que el `.tex`

### Referencias no aparecen
```bash
bibtex main_completo
pdflatex main_completo.tex
pdflatex main_completo.tex
```

### Diagramas no se renderizan
Verifica que `\usetikzlibrary{...}` esté en el preámbulo (línea 17)

### Limpiar archivos auxiliares
```bash
rm *.aux *.log *.bbl *.blg *.toc *.out *.fls *.fdb_latexmk *.synctex.gz
```

---

## 💡 Para la Defensa/Presentación

### Puntos Clave a Destacar

1. **"Rechazamos científicamente la hipótesis"**
   - Demuestra rigor, no sesgo de confirmación

2. **"Implementamos desde cero ambos algoritmos"**
   - No usamos librerías de ordenamiento
   - Código educativo documentado

3. **"Integramos auténticamente dos materias"**
   - Programación I: herramientas (Pandas, Flask)
   - Estructura de Datos: fundamentos (algoritmos)

4. **"Aplicamos al contexto ecuatoriano"**
   - ANT, placas vehiculares
   - Problema real de peajes electrónicos

5. **"Descubrimos que la teoría no es suficiente"**
   - Constantes ocultas importan
   - Hardware y arquitectura son decisivos

### Preguntas Frecuentes

**Q: ¿Por qué Radix Sort no fue superior?**
**A**: Para n=1000, las constantes ocultas (overhead, múltiples pasadas, caché) igualan el rendimiento. Sería superior con n > 10⁶.

**Q: ¿Qué aprendieron del proyecto?**
**A**: Que la complejidad asintótica es fundamental pero insuficiente. Los factores prácticos son decisivos en aplicaciones reales.

---

## 📦 Archivos para Entregar

### Mínimo
```
main_completo.pdf  ← Solo el PDF compilado
```

### Completo (recomendado)
```
main_completo.pdf
main_completo.tex
referencias.bib
diagramas_uml.tex (opcional)
logos/*.png
```

---

## 📊 Estadísticas

- **Páginas**: ~20-25
- **Secciones**: 10 principales
- **Código Python**: ~240 líneas documentadas
- **Referencias**: 10 académicas
- **Tablas**: 1 de resultados experimentales
- **Diagramas opcionales**: 8 UML/flowcharts

---

## ✨ Estado

✅ **DOCUMENTO COMPLETO Y LISTO PARA COMPILAR**

---

**Creado**: Enero 2025
**Autores**: Juan David Ruiz, Estefany Condor, Natasha Núñez, Kléver Castillo, Ian Nolivos, Elmer Rivadeneira
**Docentes**: Mg. José Zúñiga (Programación I), Mg. Evelyn Rosero (Estructura de Datos)
**Institución**: Universidad Nacional de Chimborazo - Facultad de Ingeniería
