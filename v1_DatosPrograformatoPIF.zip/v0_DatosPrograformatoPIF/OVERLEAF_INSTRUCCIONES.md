# 📝 Instrucciones para Overleaf

## ✅ Problema Resuelto

El error **"Can be used only in preamble"** se debía a que `diagramas_uml.tex` intentaba cargar paquetes con `\usepackage` después de `\begin{document}`.

**Solución aplicada**: Se eliminaron los comandos `\usepackage` y `\usetikzlibrary` del archivo `diagramas_uml.tex`.

---

## 🚀 Cómo Usar en Overleaf

### Opción 1: Sin Diagramas (Más Simple)

Sube solo estos archivos a Overleaf:

```
- main_completo.tex
- referencias.bib
- logo_unach.png
- logo_white_unach.png
- logo_sgc.png
```

Compila `main_completo.tex` normalmente.

---

### Opción 2: Con Diagramas UML

#### Paso 1: Subir Archivos

Sube TODOS estos archivos a Overleaf:

```
- main_completo.tex
- referencias.bib
- diagramas_uml.tex
- logo_unach.png
- logo_white_unach.png
- logo_sgc.png
```

#### Paso 2: Verificar Preámbulo

Asegúrate de que `main_completo.tex` tenga en el preámbulo (líneas 16-17):

```latex
\usepackage{tikz}
\usetikzlibrary{shapes.geometric, arrows, positioning, fit, backgrounds, calc, shapes.multipart}
```

**Ya está incluido**, no necesitas agregarlo.

#### Paso 3: Cargar Diagramas

En `main_completo.tex`, **después de** `\begin{document}` (alrededor de línea 102), agrega:

```latex
\begin{document}

% Cargar diagramas UML
\input{diagramas_uml.tex}

% ... resto del documento
```

#### Paso 4: Insertar Diagramas

En las ubicaciones deseadas, inserta los comandos:

```latex
% Ejemplo en Sección 7.2 - Marco Teórico
\diagramaComplejidad

% Ejemplo en Sección 7.3.1 - Arquitectura
\diagramaArquitectura

% Ejemplo en Sección 7.4.1 - Merge Sort
\diagramaFlujoMergeSort
```

**Lista completa de comandos**:

1. `\diagramaComplejidad` - Gráfico de complejidades
2. `\diagramaArquitectura` - Arquitectura en capas
3. `\diagramaFlujoBusqueda` - Flujo completo de búsqueda
4. `\diagramaSecuencia` - Diagrama de secuencia
5. `\diagramaCasosUso` - Casos de uso
6. `\diagramaFlujoMergeSort` - Flowchart Merge Sort
7. `\diagramaFlujoRadixSort` - Flowchart Radix Sort
8. `\diagramaModeloDatos` - Modelo entidad-relación

---

## 🧪 Probar Diagramas (Opcional)

Para verificar que todos los diagramas compilen correctamente, sube también:

```
- test_diagramas.tex
```

Y compila `test_diagramas.tex`. Este archivo genera un PDF con los 8 diagramas para verificación.

---

## ⚠️ Errores Comunes en Overleaf

### Error: "Undefined control sequence \diagramaXXX"

**Causa**: No se cargó `diagramas_uml.tex`

**Solución**: Agregar `\input{diagramas_uml.tex}` después de `\begin{document}`

---

### Error: "Can be used only in preamble"

**Causa**: Intentaste cargar `diagramas_uml.tex` en el preámbulo

**Solución**: Mover `\input{diagramas_uml.tex}` DESPUÉS de `\begin{document}`

❌ **Incorrecto**:
```latex
\usepackage{tikz}
\input{diagramas_uml.tex}  % MAL - antes de \begin{document}

\begin{document}
```

✅ **Correcto**:
```latex
\usepackage{tikz}

\begin{document}
\input{diagramas_uml.tex}  % BIEN - después de \begin{document}
```

---

### Error: "Package tikz Error: Unknown shape"

**Causa**: Falta alguna librería de TikZ

**Solución**: Verificar que el preámbulo tenga:
```latex
\usetikzlibrary{shapes.geometric, arrows, positioning, fit, backgrounds, calc, shapes.multipart}
```

---

### Diagrama muy grande / se sale de la página

**Solución**: Ajustar el parámetro `scale` en el diagrama específico.

Ejemplo, busca en `diagramas_uml.tex`:
```latex
\begin{tikzpicture}[scale=0.9, every node/.style={scale=0.9}]
```

Cámbialo a:
```latex
\begin{tikzpicture}[scale=0.7, every node/.style={scale=0.7}]
```

---

## 📋 Checklist de Compilación

Antes de compilar en Overleaf:

- [ ] ✅ Subiste `main_completo.tex`
- [ ] ✅ Subiste `referencias.bib`
- [ ] ✅ Subiste los 3 logos PNG
- [ ] ✅ (Opcional) Subiste `diagramas_uml.tex`
- [ ] ✅ El preámbulo tiene `\usepackage{tikz}` y `\usetikzlibrary{...}`
- [ ] ✅ `\input{diagramas_uml.tex}` está DESPUÉS de `\begin{document}`
- [ ] ✅ Compilador configurado: pdfLaTeX + BibTeX

---

## 🎯 Compilación en Overleaf

1. Selecciona **Compiler: pdfLaTeX** (menú izquierdo)
2. Haz clic en **Recompile**
3. Si hay cambios en la bibliografía, puede requerir 2 compilaciones

**Tiempo de compilación**: ~30-60 segundos (con diagramas)

---

## ✨ Resultado Esperado

- **Sin diagramas**: ~20 páginas
- **Con 8 diagramas**: ~25-28 páginas

---

## 🔧 Solución Rápida si Nada Funciona

Si tienes problemas con los diagramas en Overleaf:

1. **Compila sin diagramas**: Comenta o elimina `\input{diagramas_uml.tex}`
2. **Documento completo funcional**: El PDF se generará sin diagramas pero con todo el contenido técnico, código, tablas y referencias

El documento es completo y profesional **con o sin** los diagramas UML.

---

**Última actualización**: 24 de enero de 2025
**Versión**: Corregida para Overleaf
